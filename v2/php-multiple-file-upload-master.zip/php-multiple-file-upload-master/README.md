# php-multiple-file-upload
PHP 7 Multiple Files and Images uploading tutorial, and we will learn to store uploaded files in the MySQL database along with some necessary file uploading validation.

[PHP 7 Multiple Files/Images Upload in MySQL Database](https://www.positronx.io/php-multiple-files-images-upload-in-mysql-database/) 